<?php
$mod_strings = array(
	'ProductLines'=>'Продуктови линии',
	'SINGLE_ProductLines'=>'Продуктова линия',
	'LBL_PRODUCTLINES_INFORMATION'=>'Продуктова линия информация',
	'LBL_CUSTOM_INFORMATION'=>'Персонализирана информация',
	'LBL_DESCRIPTION_INFORMATION'=>'Описание информация',
	'ProductLineName'=>'Име на линия',
);
?>