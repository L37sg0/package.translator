<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'Сметки',
    'LBL_MODULE_TITLE'=>'Сметки: начало',
);
?>