import re
import json
from os import listdir


class DictionaryMaker:
    def __init__(self):
        self.sourcedir = "/home/reghack/Desktop/vtesource/vtenext19ce/modules" 
        self.dictionary = "/home/reghack/Desktop/package.translator/tests/bigdic3.json"
        self.targetdir = "/home/reghack/Desktop/package.translator/modules"
        self.regex = "=>\'(.+?)\',"
        self.regex_key = "\'(.+?)\'=>\'"

    def read_and_match(self, filename):                         # Read file match regex and return list of all matches
        with open(filename,"r") as fn:
            line = fn.readline()
            #words = []     
            pair = {}                                     # Empty dict that stores all matched words.
            while line:
                match_key = re.search(self.regex_key, line)
                match_word = re.search(self.regex, line)             # Matching words in line sorted by regex.
                if match_word:
                    pair[match_key.group(1)] = match_word.group(1)
                    #words.append(match_key.group(1))           # Appending mathched word into storage.
                line = fn.readline()                          # Read next line.
            #return(words) 
            return(pair)   
                
    def store_as_json(self,data,filename):                      # Method for storing data as a json file.
            data = json.dumps(data)
            with open(filename, "w") as fn:
                fn.write(data)

    def iterate_over_dirs(self):                                    # Iterate over targetdir 
                                                                    # and add all matches in subdictionary
        sourcelist = listdir(self.sourcedir)
        data = set()
        for directory in sourcelist:
            filename = self.sourcedir+"/"+directory+"/language/en_us.lang.php"
            try:
                result = set(self.read_and_match(filename))
                data = data.union(result)
            except EnvironmentError as error:
                print(error)
        data = list(data)
        self.store_as_json(data, self.dictionary)

    def translate_dictionary(self):                                 # Open source, target and
                                                                    # translate dictionary
        #sourcelist = listdir(self.sourcedir)
        targetlist = listdir(self.targetdir)
        #data = set()
        source_result = {}
        target_result = {}
        dictionary = []
        for target in targetlist:
            source_file = self.sourcedir+"/"+target+"/language/en_us.lang.php"
            target_file = self.targetdir+"/"+target+"/language/bg_bg.lang.php"
            try:
                source_result.update(self.read_and_match(source_file))
                target_result.update(self.read_and_match(target_file))
            except EnvironmentError as error:
                print(error)
        #source_result = [item for sublist in source_result for item in sublist]
        #target_result = [item for sublist in target_result for item in sublist]
        #result = set(zip(source_result, target_result))
        #result = list(result)

        #result = zip(source_result, target_result)
        #for (s, t) in result:
        for item in source_result:
            #key = item.keys()
            data = {}
            try:
                data["en"] = source_result[item]
                data["bg"] = target_result[item]
                dictionary.append(data)
            except EnvironmentError as error:
                print(error)
        #dictionary = list(set(dictionary))
        self.store_as_json(dictionary, self.dictionary)



test = DictionaryMaker()
#test.iterate_over_dirs()
test.translate_dictionary()
#filename = "/home/reghack/Desktop/vtesource/vtenext19ce/modules/Accounts/language/en_us.lang.php"
#res = test.read_and_match(filename)
#print(res)





